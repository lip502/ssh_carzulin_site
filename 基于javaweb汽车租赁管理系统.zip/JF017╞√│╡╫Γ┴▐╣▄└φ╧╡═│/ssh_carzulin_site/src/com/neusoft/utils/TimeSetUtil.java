package com.neusoft.utils;

public class TimeSetUtil {

	 public static String startTime = "2015-09-01";
	 public static String endtTime = "2016-07-01";

	 

}

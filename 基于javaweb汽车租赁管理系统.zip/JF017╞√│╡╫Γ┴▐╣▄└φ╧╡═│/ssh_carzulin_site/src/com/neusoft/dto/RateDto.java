package com.neusoft.dto;

public class RateDto {

	
	private String price;//按照月份总计价格
	
	private String month;//月份

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}
	
	
}
